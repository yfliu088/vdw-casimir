%������ʵ�ֵ�Ϊ�ִ����ۻ�ϵ�PWS�㷨����ϸ��NC2021��wang����
%��������ʵ�ֶ�߶�����-�����ػ���ƽ��
%% stl�ļ�ת��Ϊ�����ļ�
tic;
clc;
clear all;
% �������
T=298.15; %room temperature
lrr=0.01;  %��λΪ΢��
err=1e-6; %�������ֵ������ֵ
mk=mktest(lrr*1e-6,T,err); %ȷ����ԭƵ�ʽ��������뵥λ��ҪΪ��
tsn=127; %�������ظ���-Խ�����Խ��ȷ������ʱ������ܴ�-�˴���������Ϊ2^n-1

% input the stl file-plan A
[f,n,v]=stlread('LS01');
xo=mean(f);
yo=mean(n);
zo=mean(v);
xx=xo'-mean(xo);
yy=yo'-mean(yo);
zz=zo'-mean(zo);
[theta0,lambda0,r0]=cart2sph(xx,yy,zz);
theta0=theta0+pi;
lambda0=lambda0+pi/2;
%near refine
N=5000;
fai=(sqrt(5)-1)/2;
for i=1:N
    zf(i)=(2*i-1)/N-1;
    xf(i)=sqrt(1-zf(i)^2)*cos(2*pi*i*fai);
    yf(i)=sqrt(1-zf(i)^2)*sin(2*pi*i*fai);
end
[phim,thetam,rf]=cart2sph(xf,yf,zf);
phi=phim+pi;
theta=pi/2-thetam;
r = griddata(theta0,lambda0,r0,phi,theta,'nearest');
R = abs(r);       % according to color
Rxy = R.*sin(theta);    % convert to Cartesian coordinates
x = Rxy.*cos(phi);
y = Rxy.*sin(phi);
z = R.*cos(theta);
[phimo,thetamo,ro]=cart2sph(-x,-y,z);
node=[phimo',thetamo',ro'];
mro=mean(ro);
nodej=[phimo',thetamo',ro'-mro];
sphcd=[phim',thetam'];
[xt,yt,zt]=sph2cart(phim,thetam,rf+0.001.*rand(1,N));
p=[xt',yt',zt'];
[t]=MyCrust(p);
originode=[-x',-y',z',ro'];
%
RG=ro;
[xz,yz,zz]=sph2cart((sphcd(:,1))',(sphcd(:,2))',RG);
Rnode=[xz',yz',zz',RG'];
pp=Rnode(:,1:3);
%
[newnode,newface]=surfreorient(pp,t);
%volume
RgV=surfvolume(newnode,newface);
VO=4/3*pi;
sv=VO/RgV;
sl=sv^(1/3);
newnode=sl.*newnode;
% RgV2=surfvolume(newnode,newface);

% % generate special particles-planB
% % [node,face,elem]=meshabox([1 1 1],[-1 -1 -1],0.0003,0.5); %cubic
% % [node,face,elem]=meshanellip([0 0 0],[3 3 1],0.055); %Ellipsoid
% % [node,face]=meshacylinder([0 0 -4],[0 0 4],1,0.1);   %cylinder
% [node,face,elem]=meshasphere([0 0 0],1,0.055);      %sphere
% face=face(:,1:3);
% ff=reshape(face,1,3*size(face,1));
% ff=unique(ff);
% temp=face;
% for i=1:length(ff)
%     temp(face==ff(i))=i;
% end
% zz=node(ff,:);
% %
% [newnode,newface]=surfreorient(zz,temp);
% %volume
% RgV=surfvolume(newnode,newface);
% VO=4/3*pi;
% sv=VO/RgV;
% sl=sv^(1/3);
% newnode=sl.*newnode;
% % RgV2=surfvolume(newnode,newface);



%% ����ת��ת��Ϊ�����ļ�
% ljx=max(max(max(abs(newnode))))*1.5;
% % xi=-4:0.04:4;
% xi=linspace(-ljx,ljx,tsn+1);
% % yi=-4:0.04:4;
% yi=linspace(-ljx,ljx,tsn+1);
% % zi=-4:0.04:4;
% zi=linspace(-ljx,ljx,tsn+1);
% img=surf2vol(newnode,newface,xi,yi,zi,'fill',1);

%msh_node
nn=size(newnode,1);
msh_node=zeros(nn,4);
msh_node(:,1)=(1:nn)'+1;
msh_node(:,2:4)=newnode;

%write information of node
nodenum=(1:nn)';
nodef=[nodenum newnode];
% fid = fopen('n2.node','a+');
% fprintf(fid,'%d %.8f %.8f %.8f\n',nodef');
% fclose(fid);

%% obtain the rotation angle
%input origin node data
% an=load('n2.node');
an=nodef;
lown=an;
upn=an;
% upn(:,4)=an(:,4);
%Random rotation-lower particle 
%rotation matrix
% a=2*pi*rand(1,1);
a=4.2898;
% b=2*pi*rand(1,1);
b=1.9625;
% th=2*pi*rand(1,1);
th=2.4908;
Rx=[1 0 0 0;0 cos(a) sin(a) 0;0 -sin(a) cos(a) 0;0 0 0 1];
Ry=[cos(b) 0 -sin(b) 0;0 1 0 0;sin(b) 0 cos(b) 0;0 0 0 1];
Rz=[cos(th) sin(th) 0 0;-sin(th) cos(th) 0 0;0 0 1 0;0 0 0 1];
TT=Rx*Ry*Rz;
%rotation
N=size(an,1);
lownr=[lown(:,2:4) ones(N,1)]*TT;
lownr(:,2:4)=lownr(:,1:3);
lownr(:,1)=lown(:,1);
%������ת���node
lownode=lownr(:,2:4);
lr=[a b th];
%��ת�󱣴������ļ�
ljx=max(max(max(abs(lownode))))*1.5;
% xi=-4:0.04:4;
xi=linspace(-ljx,ljx,tsn+1);
% yi=-4:0.04:4;
yi=linspace(-ljx,ljx,tsn+1);
% zi=-4:0.04:4;
zi=linspace(-ljx,ljx,tsn+1);
img=surf2vol(lownode,newface,xi,yi,zi,'fill',1);



%Random rotation-upper particle 
% a=2*pi*rand(1,1);
a=0;
% b=2*pi*rand(1,1);
b=0;
% th=2*pi*rand(1,1);
th=0;
Rx=[1 0 0 0;0 cos(a) sin(a) 0;0 -sin(a) cos(a) 0;0 0 0 1];
Ry=[cos(b) 0 -sin(b) 0;0 1 0 0;sin(b) 0 cos(b) 0;0 0 0 1];
Rz=[cos(th) sin(th) 0 0;-sin(th) cos(th) 0 0;0 0 1 0;0 0 0 1];
TT=Rx*Ry*Rz;
%
upnr=[upn(:,2:4) ones(N,1)]*TT;
upnr(:,2:4)=upnr(:,1:3);
upnr(:,1)=upn(:,1);
%������ת���node
upnode=upnr(:,2:4);
%Translation
upnr(:,4)=upnr(:,4)+5;
ur=[a b th];
%��ת�󱣴������ļ�
ljx=max(max(max(abs(upnode))))*1.5;
% xi=-4:0.04:4;
xi=linspace(-ljx,ljx,tsn+1);
% yi=-4:0.04:4;
yi=linspace(-ljx,ljx,tsn+1);
% zi=-4:0.04:4;
zi=linspace(-ljx,ljx,tsn+1);
imgu=surf2vol(upnode,newface,xi,yi,zi,'fill',1);

% %% obtain the translation distance of the upper particle-linear interpolation
% %process of contact
% %project
% lowp=lownr((lownr(:,4)>0),:);
% upp=upnr((upnr(:,4)<5),:);
% xl=lowp(:,2);
% yl=lowp(:,3);
% zl=lowp(:,4);
% xu=upp(:,2);
% yu=upp(:,3);
% zu=upp(:,4);
% %project plan
% xtemp=linspace(min(min(xl),min(xu)),max(max(xl),max(xu)),100);
% ytemp=linspace(min(min(yl),min(yu)),max(max(yl),max(yu)),100);
% [X,Y]=meshgrid(xtemp,ytemp);
% Zl=griddata(xl,yl,zl,X,Y,'linear');
% Zu=griddata(xu,yu,5-zu,X,Y,'linear');
% Zz=Zu+Zl;
% z_d=5-max(max(Zz));
% upnr(:,4)=upnr(:,4)-z_d+lrr;
% zde=5-z_d+lrr;

%% PWS����
%΢��ת��
LL=1e-6;
VL=LL.^3;
%���طָ�
mb = multblock(img);
mbu = multblock(imgu);
%������Ҫ�ı�������
sd=(VO/(sum(sum(sum(img))))).^(1/3).*LL; %�������ű���
vt1=VO/(sum(sum(sum(img)))).*VL;         %������ű���
sdu=(VO/(sum(sum(sum(imgu))))).^(1/3).*LL;
vt2=VO/(sum(sum(sum(imgu)))).*VL;
%����������ת��Ϊ��ʵ����
for jk1=1:size(mb,2)
     zt=cell2mat(mb(2,jk1));
     xd(jk1)=zt(1)*sd;
     yd(jk1)=zt(2)*sd;
     zd(jk1)=zt(3)*sd;
     vtd(jk1)=cell2mat(mb(3,jk1))*vt1;
     %��¼����һ��Ϊ1�ĵط�
     if jk1>1
     tem1=cell2mat(mb(1,jk1));
     tem2=cell2mat(mb(1,jk1-1));
     if size(tem1,1)==1 & size(tem2,1)~=1
         sk1=jk1;
     end
     end
end
tsp=[xd' yd' zd'];
for jk2=1:size(mbu,2)
     ztu=cell2mat(mbu(2,jk2));
     xdu(jk2)=ztu(1)*sdu;
     ydu(jk2)=ztu(2)*sdu;
     zdu(jk2)=ztu(3)*sdu;
     vtdu(jk2)=cell2mat(mbu(3,jk2))*vt2;
     %��¼����һ��Ϊ1�ĵط�
     if jk2>1
     tem1=cell2mat(mbu(1,jk2));
     tem2=cell2mat(mbu(1,jk2-1));
     if size(tem1,1)==1 & size(tem2,1)~=1
         sk2=jk2;
     end
     end
end
tspu=[xdu' ydu' zdu'];

%����ƽ�ƾ���
imgg=img(:,:,((tsn+1)/2+1):tsn+1);
iz=sum(imgg,3);
imggu=imgu(:,:,1:(tsn+1)/2);
izu=sum(imggu,3);
z_z=iz+izu;
zde=max(max(z_z))*sd+lrr.*LL;
tspu(:,3)=tspu(:,3)+zde;

%����������
uc=0;
parfor i=1:length(xd);
    for j=1:length(xdu);
       pwsr=sqrt((tsp(i,1)-tspu(j,1)).^2+(tsp(i,2)-tspu(j,2)).^2+(tsp(i,3)-tspu(j,3)).^2);
       uc=uc+fpws(pwsr,mk,T,vtd(i),vtdu(j));
    end
end
uc
totalt=toc

